﻿#ifdef _WIN32
#include <windows.h>
#endif
#include <iostream>
#include <string>
#include <thread>
#include <chrono>
#include "bot/BotApp.h"
#include "db/Database.h"
#include "services/ReminderService.h"
#include "logging/Logger.h"

int main() {
#ifdef _WIN32
    SetConsoleOutputCP(CP_UTF8);
    SetConsoleCP(CP_UTF8);
#endif
    const std::string token = "8311647509:AAEt2noKJrydmW1HzFWF6LTu5_HUiRjdD2c";
    const std::string dbPath = "data/PopWordBot.db";

    try {
        Database db(dbPath);
        db.init();

        // Запуск фонового потока для рассылки напоминаний (например, раз в 6 часов)
        std::thread reminderThread([&db, token]() {
            ReminderService reminderService(db, token);
            while (true) {
                // Задержка перед первой/следующей отправкой (например, 6 часов)
                std::this_thread::sleep_for(std::chrono::hours(6));

                Logger::info("Запуск фоновой рассылки напоминаний...");
                reminderService.sendReminders();
            }
            });

        // Отсоединяем поток, чтобы он работал независимо от основного
        reminderThread.detach();

        // Запуск основного Telegram-бота (блокирующий вызов)
        std::cout << "PopWordBot is running..." << std::endl;
        BotApp app(token);
        app.run();

    }
    catch (const std::exception& e) {
        Logger::error("Критическая ошибка в main: " + std::string(e.what()));
        return 1;
    }

    return 0;
}